def part1():
    """add your code here"""


def part2():
    """add your code here"""


def part3():
    """add your code here"""


def part4():
    """add your code here"""


def part5():
    """add your code here"""

if __name__ == '__main__':
    part1()
    part2()
    part3()
    part4()
    part5()



